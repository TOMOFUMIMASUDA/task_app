# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'd759cf5bac516eaa09b1ba7cf73c2546075ae769341213835e84ea1a56195808e7999f89d7c4ace35c726d5852235c85fe84d1d38ac131c7ed832b7f6f0e075a'
